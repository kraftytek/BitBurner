/** @param {NS} ns */
export async function main(ns) {

  ns.tail("hacknet.js");

 var totalHash = ns.hacknet.numHashes();
  var sellCost = ns.hacknet.hashCost("Sell for Money");

  var buyAll = Math.floor(totalHash / sellCost);


  ns.hacknet.spendHashes("Sell for Money","", buyAll);
  ns.print("Sold " + buyAll + " hashes");
}