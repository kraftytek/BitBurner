//import * as help from './helper.js';
/** @param {NS} ns */

import * as help from './helper.js';

export async function main(ns) {
ns.tail("test.js");
var serverList = help.serverList(ns);


const runLengthEncoding = (string) => {

  let result = '';
  let count = 1;

  for (let i = 0; i < string.length; i++) {
    let j = i + 1;
    while (string[i] === string[j]) {
      count++;
      if (count === 9) {
        j++;
        break;
      } else {
        j++;
      }
    }
    result = result.concat(`${count}${string[i]}`);
    count = 1;
    i = j - 1;
  }
  return result;
}

for(let x = 0; x < 1; x++){
  var currentServer = serverList[x];
  var serContract = ns.ls(currentServer);
  ns.print(serContract[0]);
  var contractDesc = ns.codingcontract.getDescription(serContract[0], currentServer);
  ns.print(contractDesc);
  var answer = runLengthEncoding("66666666AABBGQQQQQQQqqqqqqqqqqqfCIi4455665GGGGRRRRRRRRRRRRLkiiiii");
  ns.print(answer);
}




}
